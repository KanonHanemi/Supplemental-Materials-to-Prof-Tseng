function Write(info, name)

n = size(indo,1);
text_str = cell(n,1);

for i = 1:n
    text_str{i} = name(i);
end
position = 






end