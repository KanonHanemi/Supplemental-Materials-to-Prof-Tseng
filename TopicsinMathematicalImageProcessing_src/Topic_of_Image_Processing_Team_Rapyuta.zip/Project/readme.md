This is the instruction of the program of final project.

The Copyright of the program belongs to the author, Wei-Chih Chen.
The ownership of the PTA chart belongs to Taichung Veterans General Hospital.

All of the project materials should contained in one folder, including the test input.
The newest algorithm is version 5.1.
The experimental program is the "backup.m", it uses the function which shows the detail.
The formal program is the "main.m", it can generate an output file.
Try not to modify the code or any of the files.

How to use this program:
1. Open up the "backup.m" or "main.m" file
2. Modify the input file name inside the code(the only part that user is allowed to change is the input).
3. Run the code.
4A. If you run the "backup.m", open the "dialogue" variable, the explanation is included in the program.
4B. If you run the "main.m", the result will output at the terminal, do as it says.

2024.06.14